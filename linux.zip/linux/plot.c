#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <termios.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>

#include "defines.h"
#include "glcdfont.c"

#define SCALE 2 // screen size scaling. (usually between 1 and 5)

#define WIDTH  (128*SCALE)  // Arduboy 128x64 screen
#define HEIGHT (64*SCALE)

extern const unsigned char tiles24x16[];
extern const unsigned char tiles4x4[];

unsigned char buffer[1024];
Display *display;
Window  window;
XSetWindowAttributes attributes;
XGCValues gr_values;
XFontStruct *fontinfo;
GC gr_context;
Visual *visual;
int depth,screen;
XEvent event;
XColor colorWhite, colorBlack, dummy;
unsigned char keys[32];



//----------------------------------------------------------------
int xinit(int argc, char *argv[])
{
    display = XOpenDisplay(NULL);
    if (display == NULL) {
        fprintf(stderr, "Unable to open X display\n");
        exit(1);
    }
    screen = DefaultScreen(display);
    visual = DefaultVisual(display,screen);
    depth  = DefaultDepth(display,screen);
    attributes.background_pixel = XWhitePixel(display,screen);
 
    window = XCreateWindow( display,XRootWindow(display,screen),
                 0,0, WIDTH, HEIGHT, 5, 
                 depth,  InputOutput, visual ,CWBackPixel, &attributes);

    XSelectInput(display,window,ExposureMask | KeyPressMask) ;
    fontinfo = XLoadQueryFont(display,"fixed"); // anything from xlsfonts
     
    XAllocNamedColor(display, DefaultColormap(display, screen),"white",
                      &colorWhite,&dummy);
    gr_values.font = fontinfo->fid;
    gr_values.foreground = colorBlack.pixel;
    gr_context=XCreateGC(display,window,GCFont+GCForeground, &gr_values);
    XSetStandardProperties(display,window, "Arduboy", "Arduboy",
                      (Pixmap)NULL, argv, argc, NULL);
    XMapWindow(display,window);
    XFlush(display);
    usleep(10000); // seems necessary, don't know why.
    return(ConnectionNumber(display));
}

//----------------------------------------------------------------
void plot(int x, int y)
{
    int i; 
    
    //printf("plot...\n");
    XSetForeground(display, gr_context, colorBlack.pixel);
    for (i=0; i<SCALE; i++)
      XDrawLine(display,window,gr_context,
                x*SCALE,y*SCALE+i,(x+1)*SCALE-1,y*SCALE+i);
}

//----------------------------------------------------------------
void unplot(int x, int y)
{
    int i; 
    
    //printf("unplot...\n");   
    XSetForeground(display, gr_context, colorWhite.pixel);
    for (i=0; i<SCALE; i++)
      XDrawLine(display,window,gr_context,
                x*SCALE,y*SCALE+i,(x+1)*SCALE-1,y*SCALE+i);   
}

//--------------------------------------------------------
void display_display()
{
  int x,y,y2,a;
  // modded to write buffer[] out instead......
  for (y=0; y<8; y++) for (x=0; x<128; x++) {
    a=buffer[y*128+x];
    for (y2=0; y2<8; y2++) {
       if (a%2==1) unplot(x,y*8+y2); else plot(x,y*8+y2);
       a=a/2;
    }
  }
  XFlush(display);
}

//------------------------------------------------------------
void draw_bitmap(unsigned char *bitmap, int posn, int size, int invert)
{
  int i; 
  
  if (invert) for (i=posn; i<posn+size; i++) buffer[i]=~*bitmap++;
  else for (i=posn; i<posn+size; i++) buffer[i]=*bitmap++;
}

//------------------------------------------------------------
void grey_screen()
{
  int i;
  for (i=0; i<1024; i++)
     if (i%2==1) buffer[i]=170; else buffer[i]=85;
}

//------------------------------------------------------------
void black_screen()
{
  int i;
  for (i=0; i<1024; i++) buffer[i]=0;
}

//------------------------------------------------------------
void white_screen()
{
  int i;
  for (i=0; i<1024; i++) buffer[i]=255;
}

//--------------------------------------------------------
void draw24x16tile(int tile,int x, int y)
{
  int x2,y2;
  for (y2=0; y2<2; y2++) for (x2=0; x2<24; x2++)
    buffer[4+x*24+x2+y*128*2+y2*128]=tiles24x16[tile*24*2+y2*24+x2];
}

//--------------------------------------------------------
// this takes 2 stacked tiles to draw (8 bit depth)
void draw4x4tile(int tile1,int tile2, int x, int y)
{ 
  int i,z;
  unsigned char a;
  
  for (i=0; i<4; i++) {
    a=tiles4x4[tile2*4+i]*16+tiles4x4[tile1*4+i];
    buffer[x*4+y/2*128+i]=a;
  };  
}

//------------------------------------------------------------
// prints text at location x,y. y is usually a multiple of 8.
void print(int x, int y, char *s, int colour)
{
  char c;
  int i;
  
  c=*s++; 
  while(c!=0) {
    if (colour==1) {  
      for (i=0; i<5; i++) buffer[x+++y/8*128]=*(font+c*5+i);
       buffer[x+++y/8*128]=0;
    } else {
       for (i=0; i<5; i++) buffer[x+++y/8*128]=~*(font+c*5+i);
       buffer[x+++y/8*128]=255;
    }
    c=*s++; // next character in the string
  }
}

//------------------------------------------------------------
int read_keys()
{
  FILE *fp;
  unsigned char bmp[1086];
  int a,i,x,y,posn=1070;
  
  XQueryKeymap(display, keys);
  
  if (keys[13]&128) return(KEY_UP);
  if (keys[14]&16) return(KEY_DOWN);
  if (keys[14]&2) return(KEY_LEFT);
  if (keys[14]&4) return(KEY_RIGHT);
  if (keys[6]&4) return(KEY_A);
  if (keys[4]&32) return(KEY_B);
  //for (i=0; i<32; i++) printf("%i ",keys[i]); printf("\n");
  if (keys[4]&2) {
    fp=fopen("screenshot.bmp","r");
    fread(bmp,1086,1,fp); fclose(fp);
   
    for (y=0; y<64; y++) { // normally 64...
      for (x=0; x<16; x++) {
       a=0; for (i=0; i<8; i++)
          {a*=2; if ((buffer[(y/8)*128+x*8+i] & 1<<(y%8))!=0) a++;}
       bmp[posn+x]=a;
      }
      posn-=16;
    }
    fp=fopen("screenshot.bmp","w");
    fwrite(bmp,1086,1,fp); fclose(fp);
 
  }
  return(0); 
}

//---------------------------------------------------------------
void delay(int i)
{
  usleep(i*1000);
}



