// generate a 48x24 BMP file based on 6x5 character mazog graphic.

#include <stdio.h>
#include "../../charset.c"
#include "../../charset_inv.c"

#define TILES 37

char files48x40[37][80]={
"still.bmp",
"updown1.bmp",
"updown2.bmp",
"right1.bmp",
"right2.bmp",
"left1.bmp",
"left2.bmp",
"fight1.bmp",
"fight2.bmp",
"fight3.bmp",
"still_t.bmp",
"right1_t.bmp",
"right2_t.bmp",
"left1_t.bmp",
"left2_t.bmp",
"updown1_t.bmp",
"updown2_t.bmp",
"up1_t.bmp",
"up2_t.bmp",
"mazog1.bmp",
"mazog2.bmp",
"prisoner1.bmp",
"prisoner2.bmp",
"clear.bmp",
"wall.bmp",
"trail.bmp",
"thisway.bmp",
"treasure1.bmp",
"treasure2.bmp",
"sword.bmp",
"still_s.bmp",
"right1_s.bmp",
"right2_s.bmp",
"left1_s.bmp",
"left2_s.bmp",
"updown1_s.bmp",
"updown2_s.bmp",

};

int location[TILES]={
17470,
17500,
17530,
17560,
17590,
17620,
17650,
17680,
17710,
17740,
17770,
17800,
17830,
17860,
17890,
17930,
17960,
17990,
18020,
18050,
18080,
18110,
18140,
18170,
18200,
18230,
18260,
18290,
18320,
18350,
18390,
18420,
18450,
18480,
18510,

18540,
18570
};

main()
{
  FILE *fp;
  int posn;
  int x,y,i,f;
  unsigned char ram[65536];
  unsigned char bmp[382];
  unsigned char byte;
  
  fp=fopen("mazogs.ramdump","r"); fread(ram,65536,1,fp); fclose(fp);

  for (f=0; f<TILES; f++) {  
    fp=fopen("48x40blank.bmp","r"); fread(bmp,382,1,fp); fclose(fp);
    posn=location[f]; // location in ZX81 RAM of this graphic.
    for (y=0; y<5; y++) {
      for (x=0; x<6; x++) {
        byte=ram[posn++];
        for (i=0; i<8; i++) {
           if (byte>127)
           bmp[374-(y*64)-(i*8)+x]=zx81chars_inv[(byte-128)*8+i];
	   else
	   bmp[374-(y*64)-(i*8)+x]=zx81chars[byte*8+i];
        }
      }
    }  
    fp=fopen(files48x40[f],"w"); fwrite(bmp,382,1,fp); fclose(fp);
  }
}
