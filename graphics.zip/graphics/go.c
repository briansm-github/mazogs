// generate tiles24x16.h and tiles4x4.h files from .BMP source files.
#include <stdio.h>

#define NUM_24x16_TILES 46
#define NUM_4x4_TILES 12

char files24x16[NUM_24x16_TILES][80]={
"clear.bmp",
"wall.bmp",
"clear.bmp", // grey wall is clear
"sword.bmp",
"prisoner1.bmp",
"mazog1.bmp",
"treasure1.bmp",
"trail.bmp",
"thisway.bmp",
"exit.bmp",
"prisoner2.bmp",
"mazog2.bmp",
"treasure2.bmp",
"still.bmp",
"still.bmp",
"still_s.bmp",
"still_s.bmp",
"still_t.bmp",
"still_t.bmp",
"updown1.bmp",
"updown2.bmp",
"updown1_s.bmp",
"updown2_s.bmp",
"up1_t.bmp",
"up2_t.bmp",
"updown1.bmp",
"updown2.bmp",
"updown1_s.bmp",
"updown2_s.bmp",
"updown1_t.bmp",
"updown2_t.bmp",
"left1.bmp",
"left2.bmp",
"left1_s.bmp",
"left2_s.bmp",
"left1_t.bmp",
"left2_t.bmp",
"right1.bmp",
"right2.bmp",
"right1_s.bmp",
"right2_s.bmp",
"right1_t.bmp",
"right2_t.bmp",
"fight1.bmp",
"fight2.bmp",
"fight3.bmp"
};

char files4x4[NUM_4x4_TILES][80]={
"map_clear.bmp",
"map_wall.bmp",
"map_wall2.bmp",
"map_sword.bmp",
"map_prisoner.bmp",
"map_mazog.bmp",
"map_treasure.bmp",
"map_trail.bmp",
"map_thisway.bmp",
"map_exit.bmp",
"map_still.bmp",
"map_dead.bmp"
};

//-------------------------------------------------------------------
main()
{
  FILE *fp, *fpout;
  int f,h,w,a,i,posn=122,count,x,y;
  int bitmap[24][16];
  
  // first, generate tiles24x16.h.....
  fpout=fopen("../tiles24x16.c","w"); count=0;
  fprintf(fpout,"// THIS FILE IS MACHINE GENERATED\n");
  fprintf(fpout,"const unsigned char tiles24x16[] = {\n");
  for (f=0; f<NUM_24x16_TILES; f++) {
    printf("processing %s...\n",files24x16[f]);
    fp=fopen(files24x16[f],"r");
    posn=122;
    for (h=0; h<16; h++) {
      fseek(fp,posn,SEEK_SET);
      for (w=0; w<3; w++) {
        a=fgetc(fp);
        for (i=0; i<8; i++) {
	 if (a>127) bitmap[w*8+i][h]=1; else bitmap[w*8+i][h]=0;
	 a=a%128; a=a*2;
	}
      }
      posn-=4;
    }
    fclose(fp);
    
    // now output the rotated bitmap bytes...
    for (y=0; y<2; y++) for (x=0; x<24; x++) {
      a=0; for (i=7; i>=0; i--) {a*=2; if (bitmap[x][y*8+i]) a++;}
      fprintf(fpout,"0x%x, ",a); count++;
      if (count%13==12) fprintf(fpout,"\n");
    }
  }
  fprintf(fpout,"\n0};\n");
  fclose(fpout);
  
  //------------------------------------------------------------------
  // now generate files4x4.h.......
  fpout=fopen("../tiles4x4.c","w"); count=0;
  fprintf(fpout,"// THIS FILE IS MACHINE GENERATED\n");
  fprintf(fpout,"const unsigned char tiles4x4[] = {\n");
  for (f=0; f<NUM_4x4_TILES; f++) {
    printf("processing %s...\n",files4x4[f]);
    fp=fopen(files4x4[f],"r");
    posn=74;
    for (h=0; h<4; h++) {
      fseek(fp,posn,SEEK_SET);    
      a=fgetc(fp);
      for (i=0; i<4; i++) {
        if (a>127) bitmap[i][h]=1; else bitmap[i][h]=0;
	 a=a%128; a=a*2;
      }
      posn-=4;
    }
    fclose(fp);
    // now output rotated bitmap bytes
    for (x=0; x<4; x++) {
      a=0; for (i=3; i>=0; i--) {a*=2; if (bitmap[x][i]) a++;}
      fprintf(fpout,"0x%x, ",a); count++;
      if (count%13==12) fprintf(fpout,"\n");
    }
  }
  fprintf(fpout,"\n0};\n");
  fclose(fpout);  
}
